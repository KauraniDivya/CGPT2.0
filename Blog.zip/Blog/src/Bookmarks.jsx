import React from "react";

const Bookmarks = () => {
  return <div>i am bookmarks</div>;
};

export default Bookmarks;

import React from "react";

const Explore = () => {
  return <div>i am explore</div>;
};

export default Explore;

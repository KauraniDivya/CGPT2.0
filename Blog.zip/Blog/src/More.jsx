import React from "react";

const More = () => {
  return (
    <div>
      <h2>i am more</h2>
    </div>
  );
};

export default More;

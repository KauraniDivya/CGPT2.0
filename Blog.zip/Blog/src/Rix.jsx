import React from "react";

const Rix = () => {
  return (
    <div>
      <h1>hi i am rix</h1>
    </div>
  );
};

export default Rix;
